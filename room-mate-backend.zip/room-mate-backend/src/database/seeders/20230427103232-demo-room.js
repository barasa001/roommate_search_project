"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert(
      "Rooms",
      [
        {
          roomId: "558c3d83-4134-4238-9b57-18db87946cd6",
          roomNumber: parseInt("101"),
          createdAt: "2023-04-27T10:29:34.070Z",
          updatedAt: "2023-04-27T10:29:34.070Z",
        },
        {
          roomId: "26842bc2-9382-4317-87ee-2b8e626238fc",
          roomNumber: parseInt("102"),
          createdAt: "2023-04-27T10:29:44.407Z",
          updatedAt: "2023-04-27T10:29:44.407Z",
        },
        {
          roomId: "00b3fb65-336c-4a0f-8fdd-bd96a9ba5394",
          roomNumber: parseInt("103"),
          createdAt: "2023-04-27T10:29:50.059Z",
          updatedAt: "2023-04-27T10:29:50.059Z",
        },
        {
          roomId: "ea2facda-e000-42e3-9780-675f55c5ac43",
          roomNumber: parseInt("104"),
          createdAt: "2023-04-27T10:29:55.787Z",
          updatedAt: "2023-04-27T10:29:55.787Z",
        },
      ],
      {}
    );
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete("Rooms", null, {});
  },
};
