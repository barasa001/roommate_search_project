"use strict";
const bcrypt = require("bcryptjs");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.bulkInsert(
      "Users",
      [
        {
          userId: "7aa1f17e-61d5-421a-bfff-38354c9b5c3c",
          roomId: null,
          firstName: "Chriss",
          lastName: "Evans",
          email: "chriss@gmail.com",
          password: await bcrypt.hash("pass123", 12),
          picture:
            "http://res.cloudinary.com/rutagerard/image/upload/v1682589047/g98qflyi0p3vir7lygbs.jpg",
          age: 40,
          gender: "male",
          location: "Mulindi",
          bio: "Hello there! This is my bio...",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          userId: "7dce0bf8-9df8-46d0-b10b-11f46b398163",
          roomId: null,
          firstName: "Dwayne",
          lastName: "Johnson",
          email: "dwayne@gmail.com",
          password: await bcrypt.hash("pass123", 12),
          picture:
            "http://res.cloudinary.com/rutagerard/image/upload/v1682589112/gvgd8ydypdlf9yqjkps0.jpg",
          age: 54,
          gender: "male",
          location: "Biryogo",
          bio: "Hello there! This is my bio...",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          userId: "905b3014-d32b-4165-acf2-e6af5fabc1fe",
          roomId: null,
          firstName: "Rita",
          lastName: "Orra",
          email: "rita@gmail.com",
          password: await bcrypt.hash("pass123", 12),
          picture:
            "http://res.cloudinary.com/rutagerard/image/upload/v1682589160/y3aamxsncmkuovnlpqky.jpg",
          age: 30,
          gender: "female",
          location: "Kabuga",
          bio: "Hello there! This is my bio...",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          userId: "5be25f8e-5e24-4738-8105-22f4b3610ed4",
          roomId: null,
          firstName: "Bella",
          lastName: "Swan",
          email: "bella@gmail.com",
          password: await bcrypt.hash("pass123", 12),
          picture:
            "http://res.cloudinary.com/rutagerard/image/upload/v1682589237/lnlhycum51aurcec19xh.jpg",
          age: 17,
          gender: "female",
          location: "Gikondo",
          bio: "Hello there! This is my bio...",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          userId: "6505d126-616f-48b8-aad8-19480674b24c",
          roomId: "26842bc2-9382-4317-87ee-2b8e626238fc",
          firstName: "Kendrick",
          lastName: "Junior",
          email: "kendrick@gmail.com",
          password: await bcrypt.hash("pass123", 12),
          picture:
            "http://res.cloudinary.com/rutagerard/image/upload/v1682588994/m8oavceu9uzchpynft0l.jpg",
          age: 35,
          gender: "male",
          location: "Kagugu",
          bio: "Hello there! This is my bio...",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ],
      {}
    );
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete("Users", null, {});
  },
};
