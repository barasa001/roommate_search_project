import { Server } from "socket.io";

const io = new Server({
  cors: {
    origin: "*",
  },
});

io.on("connection", async (socket) => {
  console.log("Client connected", socket.id);
});

export { io };
