import "dotenv/config";
import { User, Room } from "../database/models";
import checkToken from "../helpers/checkToken";
import { decodeToken } from "../helpers/auth.helper";

export const checkUserEmailExist = async (req, res, next) => {
  try {
    const { email } = req.body;
    let emailExist = null;

    if (email) {
      emailExist = await User.findOne({
        where: {
          email,
        },
      });
    }
    if (emailExist) {
      return res
        .status(409)
        .json({ message: `User with email ${email} already exist` });
    }

    return next();
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};

export const checkUserLoggedIn = async (req, res, next) => {
  try {
    const token = checkToken(req);

    if (!token) {
      return res.status(401).json({ message: "Please login first" });
    }

    let decoded;
    try {
      decoded = decodeToken(token);
    } catch (error) {
      return res.status(401).json({
        message: "Invalid Token",
      });
    }

    req.decoded = decoded;

    return next();
  } catch (error) {
    return res
      .status(401)
      .json({ message: "Access denied", error: error.message });
  }
};

export const checkIsAuthorizedUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const token = checkToken(req);
    const userData = decodeToken(token);
    const user = await User.findByPk(userData.id, {});

    if (!user) {
      return res.status(400).json({
        message: `This provided user-id is invalid`,
      });
    }

    if (user.userId !== id) {
      return res.status(400).json({
        message: `You can not edit someone else's info`,
      });
    }
    req.user = user;

    return next();
  } catch (error) {
    return res.status(500).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};

export const checkUserIdIsValid = async (req, res, next) => {
  try {
    const { id } = req.params;
    const user = await User.findByPk(id, {});

    if (!user) {
      return res
        .status(401)
        .json({ message: "This user id you provided does not exist" });
    }

    req.user = user;

    return next();
  } catch (error) {
    return res.status(401).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};

export const checkRoomIdIsValid = async (req, res, next) => {
  try {
    const { roomId } = req.body;
    const { id } = req.params;
    let roomExist = null;

    if (roomId) {
      roomExist = await Room.findByPk(roomId, {});
      if (!roomExist) {
        return res
          .status(401)
          .json({ message: "This room id you provided does not exist" });
      }
    }
    const user = await User.findByPk(id, {});

    req.user = user;

    return next();
  } catch (error) {
    return res.status(401).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};
