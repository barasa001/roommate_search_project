import "dotenv/config";
import { Room } from "../database/models";

export const checkRoomExist = async (req, res, next) => {
  try {
    const { roomNumber } = req.body;
    let roomExist = null;

    if (roomNumber) {
      roomExist = await Room.findOne({
        where: {
          roomNumber,
        },
      });
    }
    if (roomExist) {
      return res.status(409).json({ message: "This room number is taken" });
    }

    return next();
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};

export const checkRoomIdIsValid = async (req, res, next) => {
  try {
    const { id } = req.params;
    const room = await Room.findByPk(id, {});

    console.log({ id, room });

    if (!room) {
      return res
        .status(401)
        .json({ message: "This room id you provided does not exist" });
    }

    req.room = room;

    return next();
  } catch (error) {
    return res.status(401).json({
      message: "An Unexpected error occurred",
      error: error.message,
    });
  }
};
