import RoomServices from "../services/room.services";

export default class RoomControllers {
  constructor() {
    this.roomServices = new RoomServices();
  }

  async createRoom(req, res) {
    try {
      const { roomNumber } = req.body;

      const newRoom = await this.roomServices
        .createRoom(
          {
            roomNumber,
          },
          res
        )
        .catch((error) => {
          return res.status(500).json({
            message: "Error occured while creating a room",
            error: error.message,
          });
        });

      return res.status(201).json({
        status: 201,
        message: "Room added successfully",
        data: newRoom,
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error occured while creating a room",
        error: error.message,
      });
    }
  }

  async getRooms(req, res) {
    try {
      const rooms = await this.roomServices.getRooms();

      return res.status(200).json({
        message: "Fetched rooms",
        data: rooms,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error fetching rooms",
        error: error.message,
      });
    }
  }

  async getRoom(req, res) {
    try {
      const { id } = req.params;
      const room = await this.roomServices.getRoom(id);

      return res.status(200).json({
        message: "Fetched one room",
        data: room,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error getting room",
        error: error.message,
      });
    }
  }

  async updateRoom(req, res) {
    try {
      const { roomNumber } = req.body;

      const { id } = req.params;

      const newRoom = await this.roomServices.updateRoom(req.body, {
        roomNumber,
        where: {
          roomId: id,
        },
      });
      return res.status(201).json({
        status: 201,
        message: "Room updated successfully.",
        data: newRoom,
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Failed to update room",
        error: error.message,
      });
    }
  }

  async deleteRoom(req, res) {
    try {
      const { id } = req.params;

      await this.roomServices.deleteRoom({
        where: {
          roomId: id,
        },
      });

      return res.status(200).json({
        status: 200,
        message: "Room deleted successfully",
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error occured while deleting Room",
        error: error.message,
      });
    }
  }
}
