import { generateToken } from "../helpers/auth.helper";
import { imageUpload } from "../helpers/fileUpload";
import { comparePassword, hashPassword } from "../helpers/password.helpers";
import UserServices from "../services/user.services";

export default class UserControllers {
  constructor() {
    this.userServices = new UserServices();
  }

  async createUser(req, res) {
    try {
      const {
        firstName,
        lastName,
        email,
        password,
        age,
        location,
        gender,
        bio,
      } = req.body;

      if (req.file) {
        req.body.picture = await imageUpload(req);
      }

      const newUser = await this.userServices
        .createUser(
          {
            firstName,
            lastName,
            email,
            password: hashPassword(password),
            picture: req.body.picture,
            gender,
            bio,
            age,
            location,
          },
          res
        )
        .catch((error) => {
          return res.status(500).json({
            message: "Error occured while creating a user",
            error: error.message,
          });
        });

      const userId = newUser.userId;

      const token = generateToken({ id: userId }, "1d");

      return res.status(201).json({
        status: 201,
        message: "User registered successfully",
        data: newUser,
        token,
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Error occured while creating a user",
        error: error.message,
      });
    }
  }

  async userLogin(req, res) {
    try {
      const { email } = req.body;
      const user = await this.userServices.userLogin(email);
      const validation = comparePassword(req.body.password, user.password);
      if (validation) {
        const token = generateToken(
          {
            id: user.userId,
          },
          "7d"
        );
        return res.status(201).header("authenticate", token).json({
          message: "User logged in successfully",
          data: { token, user },
        });
      }
      return res
        .status(400)
        .json({ message: "The email or password is incorrect" });
    } catch (error) {
      return res.status(500).json({
        message: "An Unexpected error occurred",
        error: error.message,
      });
    }
  }

  async getUsers(req, res) {
    try {
      const users = await this.userServices.getUsers();

      return res.status(200).json({
        message: "Fetched users",
        data: users,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error fetching users",
        error: error.message,
      });
    }
  }

  async getUser(req, res) {
    try {
      const { id } = req.params;
      const user = await this.userServices.getUser(id);

      return res.status(200).json({
        message: "Fetched one user",
        data: user,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error getting user",
        error: error.message,
      });
    }
  }

  async updateUser(req, res) {
    try {
      const { firstName, lastName, email, age, location, gender, bio, roomId } =
        req.body;

      const id = req.params.id;

      if (req.file) {
        req.body.picture = await imageUpload(req);
      }

      const newUser = await this.userServices.updateUser(req.body, {
        firstName,
        lastName,
        email,
        picture: req.body.picture,
        gender,
        bio,
        age,
        location,
        roomId,
        where: {
          userId: id,
        },
      });
      return res.status(201).json({
        status: 201,
        message: "User updated successfully.",
        data: newUser,
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        message: "Failed to update user",
        error: error.message,
      });
    }
  }

  async deleteUser(req, res) {
    try {
      const { id } = req.params;

      await this.userServices.deleteUser({
        where: {
          userId: id,
        },
      });

      return res.status(200).json({
        status: 200,
        message: "User deleted successfully",
      });
    } catch (error) {
      return res.status(500).json({
        message: "Error occured while deleting User",
        error: error.message,
      });
    }
  }
}
