const { hashSync, compareSync, genSaltSync } = require("bcryptjs");

export const hashPassword = (pwd) => {
  const salt = genSaltSync(10);
  return hashSync(pwd, salt);
};

export const comparePassword = (plainPassword, hashedPassword) => {
  const compare = compareSync(plainPassword, hashedPassword);
  return compare;
};
