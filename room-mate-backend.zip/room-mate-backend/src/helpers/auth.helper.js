const jwt = require("jsonwebtoken");

export const generateToken = (payload, expiresIn) => {
  var token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn });
  return token;
};

export const decodeToken = (token) => {
  const verify = jwt.verify(token, process.env.JWT_SECRET);
  return verify;
};
