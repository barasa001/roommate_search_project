import express from "express";
import RoomControllers from "../../controllers/room.controllers";
import {
  checkRoomExist,
  checkRoomIdIsValid,
} from "../../middlewares/room.middlewares";

const route = express.Router();

route.post("/", checkRoomExist, async (req, res) => {
  await new RoomControllers().createRoom(req, res);
});

route.get("/", async (req, res) => {
  await new RoomControllers().getRooms(req, res);
});

route.get("/:id", checkRoomIdIsValid, async (req, res) => {
  await new RoomControllers().getRoom(req, res);
});

route.patch("/:id", checkRoomIdIsValid, async (req, res) => {
  await new RoomControllers().updateRoom(req, res);
});

route.delete("/:id", checkRoomIdIsValid, async (req, res) => {
  await new RoomControllers().deleteRoom(req, res);
});

export default route;
