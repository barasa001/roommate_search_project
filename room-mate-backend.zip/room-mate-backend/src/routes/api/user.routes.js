import express from "express";
import UserControllers from "../../controllers/user.controllers";
import upload from "../../helpers/multer";
import {
  checkIsAuthorizedUser,
  checkRoomIdIsValid,
  checkUserEmailExist,
  checkUserIdIsValid,
  checkUserLoggedIn,
} from "../../middlewares/user.middlewares";

const route = express.Router();

route.post(
  "/register",
  upload.single("picture"),
  checkUserEmailExist,
  async (req, res) => {
    await new UserControllers().createUser(req, res);
  }
);

route.post("/login", async (req, res) => {
  await new UserControllers().userLogin(req, res);
});

route.get("/", async (req, res) => {
  await new UserControllers().getUsers(req, res);
});

route.get("/:id", checkUserIdIsValid, async (req, res) => {
  await new UserControllers().getUser(req, res);
});

route.patch(
  "/:id",
  upload.single("picture"),
  checkUserLoggedIn,
  checkUserIdIsValid,
  checkRoomIdIsValid,
  checkIsAuthorizedUser,
  async (req, res) => {
    await new UserControllers().updateUser(req, res);
  }
);

route.delete("/:id", checkUserIdIsValid, async (req, res) => {
  await new UserControllers().deleteUser(req, res);
});

export default route;
