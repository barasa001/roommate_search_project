import express from "express";
import roomRoutes from "./api/room.routes";
import userRoutes from "./api/user.routes";

const routes = express.Router();

routes.use("/rooms", roomRoutes);
routes.use("/users", userRoutes);

export default routes;
