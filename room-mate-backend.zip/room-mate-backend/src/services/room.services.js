import { Room, User } from "../database/models";

export default class RoomServices {
  async createRoom(data) {
    const newRoom = await Room.create(data);
    return newRoom;
  }

  async getRooms() {
    const rooms = await Room.findAll({});
    return rooms;
  }
  async getRoom(id) {
    return Room.findByPk(id, {
      include: [{ model: User, as: "users" }],
    });
  }

  async updateRoom(data, where) {
    const newRoom = await Room.update(data, where);
    return newRoom;
  }

  async deleteRoom(where) {
    const data = await Room.destroy(where);
    return data;
  }
}
