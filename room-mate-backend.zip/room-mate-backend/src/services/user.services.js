import { User, Room } from "../database/models";

export default class UserServices {
  async createUser(data) {
    const newUser = await User.create(data);
    return newUser;
  }

  async userLogin(email) {
    return User.findOne({
      where: { email },
    });
  }

  async getUsers() {
    const users = await User.findAll({});
    return users;
  }

  async getUser(id) {
    const user = await User.findByPk(id, {
      include: [{ model: Room, as: "room" }],
    });
    return user;
  }

  async updateUser(data, where) {
    const newUser = await User.update(data, where);
    return newUser;
  }

  async deleteUser(where) {
    const data = await User.destroy(where);
    return data;
  }
}
