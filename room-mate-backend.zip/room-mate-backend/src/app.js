import express from "express";
import bodyparser from "body-parser";
import db from "../src/database/models";
import routes from "./routes";
import cors from "cors";
import http from "http";
import { io } from "./utils/socket.utils";

const port = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);
io.attach(server);
app.use(
  cors({
    origin: "*",
  })
);

app.use(cors());

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

app.use("/api/v1/", routes);

db.sequelize.sync().then(() => {
  server.listen(port, () => {
    console.log(`listening on: http://localhost:${port}`);
  });
});
